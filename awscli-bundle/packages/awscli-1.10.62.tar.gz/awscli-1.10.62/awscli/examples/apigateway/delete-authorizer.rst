**To delete a Custom Authorizer in an API within the specified region**

Command::

  aws apigateway delete-authorizer --rest-api-id 1234123412 --authorizer-id 7gkfbo --region us-west-2

