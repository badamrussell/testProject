**To delete a stage in an API within the given region**

Command::

  aws apigateway delete-stage --rest-api-id 1234123412 --stage-name 'dev' --region us-west-2

