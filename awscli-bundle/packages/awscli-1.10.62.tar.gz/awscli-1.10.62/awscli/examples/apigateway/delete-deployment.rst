**To delete a deployment in an API within the specified region**

Command::

  aws apigateway delete-deployment --rest-api-id 1234123412 --deployment-id a1b2c3 --region us-west-2

