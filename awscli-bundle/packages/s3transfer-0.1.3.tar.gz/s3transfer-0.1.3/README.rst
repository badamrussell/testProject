=====================================================
s3transfer - An Amazon S3 Transfer Manager for Python
=====================================================

.. warning::

  This project is currently a work in progress. Please do not rely on
  this functionality in production as the interfaces may change over time.

S3transfer is a Python library for managing Amazon S3 transfers.
